function weather(){
var city = document.getElementById('inputValue').value;
var nameVal = document.getElementById('name');
var temp = document.getElementById('temp');
var desc = document.getElementById('desc');
fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=c41e17e6d8e4ee1ffcb898fe00eddc1e`)
.then(function(response){
    return response.json();
})
.then(function(data){
    nameVal.innerText = data.name;
    temp.innerText = data.main.temp +"℃";
    desc.innerText = data.weather[0].main;
})
.catch(function(){
    alert("city not found");
});
}
document.getElementById('button').addEventListener('click',weather)